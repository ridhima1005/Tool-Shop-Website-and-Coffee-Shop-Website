﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coffeeshop.web
{
    public class Web
    {
        public static string Test()
        {
            return "In Coffeeshop Web";
        }
    }
}
