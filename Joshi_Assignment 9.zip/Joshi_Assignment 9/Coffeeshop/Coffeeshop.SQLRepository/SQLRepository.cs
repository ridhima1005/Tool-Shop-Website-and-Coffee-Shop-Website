﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coffeeshop.SQLRepository
{
    public class SQLRepository
    {
        public static string Test()
        {
            return "In Coffeeshop SQLRepository";
        }
    }
}
