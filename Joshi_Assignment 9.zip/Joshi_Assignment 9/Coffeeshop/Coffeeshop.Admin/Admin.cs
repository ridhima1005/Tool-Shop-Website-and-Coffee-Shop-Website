﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coffeeshop.Admin
{
    using Coffeeshop.web;
    using Coffeeshop.domain;
    using Coffeeshop.Infrastructure;
    using Coffeeshop.SQLRepository;
    using Coffeeshop.MockCreditCardService;
    class Admin
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Web.Test());
            Console.WriteLine(Domain.Test());
            Console.WriteLine(SQLRepository.Test());
            Console.WriteLine(Infrastructure.Test());
            Console.WriteLine(MockCreditCardService.Test());

            Console.ReadKey(true);
        }
    }
}
