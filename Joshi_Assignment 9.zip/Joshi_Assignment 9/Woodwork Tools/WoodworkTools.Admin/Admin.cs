﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodworkTools.Admin
{
    using WoodworkTools.Web;
    using WoodworkTools.Domain;
    using WoodworkTools.SQLRepository;
    using WoodworkTools.Infrastructure;
    using WoodworkTools.MockCreditCardServi;
    class Admin
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Web.Test());
            Console.WriteLine(Domain.Test());
            Console.WriteLine(SQLRepository.Test());
            Console.WriteLine(Infrastructure.Test());
            Console.WriteLine(MockCreditCardServi.Test());

            Console.ReadKey(true);
        }
    }
}
