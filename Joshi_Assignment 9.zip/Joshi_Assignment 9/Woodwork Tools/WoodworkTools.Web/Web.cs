﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodworkTools.Web
{
    public class Web
    {
        public static string Test()
        {
            return "In Web";
        }
    }
}

