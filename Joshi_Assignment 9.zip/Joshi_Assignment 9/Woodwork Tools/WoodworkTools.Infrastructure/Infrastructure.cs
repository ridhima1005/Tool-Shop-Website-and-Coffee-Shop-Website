﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodworkTools.Infrastructure
{
    public class Infrastructure
    {
        public static string Test()
        {
            return "In Infrastructure";
        }
    }
}
