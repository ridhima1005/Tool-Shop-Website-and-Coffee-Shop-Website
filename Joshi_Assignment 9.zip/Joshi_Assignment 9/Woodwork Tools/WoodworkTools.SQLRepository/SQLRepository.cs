﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoodworkTools.SQLRepository
{
    public class SQLRepository
    {
        public static string Test()
        {
            return "In SQLRepository";
        }
    }
}
